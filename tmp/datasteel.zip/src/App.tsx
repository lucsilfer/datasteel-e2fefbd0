import React, { useState, useRef } from 'react';
import { 
  Upload, 
  FileText, 
  AlertCircle, 
  CheckCircle2, 
  Download, 
  RefreshCw,
  Beaker,
  Settings,
  ShieldCheck,
  ChevronRight,
  Edit3
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import * as pdfjsLib from 'pdfjs-dist';
// @ts-ignore
import pdfWorker from 'pdfjs-dist/build/pdf.worker.mjs?url';
import { PieChart, Pie, Cell, ResponsiveContainer, Label } from 'recharts';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

import { ChemicalElements, AnalysisResult, Status } from './types';
import { calculateCE, getElementStatus, performTechnicalAnalysis } from './utils/calculations';
import { extractDataFromImage } from './services/geminiService';

// PDF worker setup
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const INITIAL_ELEMENTS: ChemicalElements = {
  C: 0, Si: 0, Mn: 0, P: 0, S: 0, Cr: 0, Mo: 0, Ni: 0, Cu: 0, V: 0
};

export default function App() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState<AnalysisResult[]>([]);
  const [selectedHeatIndex, setSelectedHeatIndex] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [showManualInput, setShowManualInput] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isPDF = file.type === 'application/pdf';
    const isImage = file.type.startsWith('image/');

    if (!isPDF && !isImage) {
      setError('Por favor, envie um arquivo PDF ou Imagem (JPG/PNG).');
      return;
    }

    setIsAnalyzing(true);
    setError(null);
    setResults([]);
    setSelectedHeatIndex(0);

    try {
      let base64Image = '';

      if (isPDF) {
        const arrayBuffer = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        const page = await pdf.getPage(1);
        const viewport = page.getViewport({ scale: 2 });
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        if (context) {
          // @ts-ignore - pdfjs types can be tricky across versions
          await page.render({ canvasContext: context, viewport }).promise;
          base64Image = canvas.toDataURL('image/jpeg');
        }
      } else {
        base64Image = await new Promise((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.readAsDataURL(file);
        });
      }

      if (base64Image) {
        const extractedList = await extractDataFromImage(base64Image);

        if (extractedList && extractedList.length > 0) {
          const processedResults = extractedList.map(item => performTechnicalAnalysis(item));
          setResults(processedResults);
          setSelectedHeatIndex(0);
        } else {
          setError('Falha na extração automática. Por favor, insira os dados manualmente.');
          setShowManualInput(true);
        }
      }
    } catch (err) {
      console.error(err);
      setError('Erro ao processar o arquivo. Tente novamente ou insira manualmente.');
      setShowManualInput(true);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleManualSubmit = (elements: ChemicalElements, dimensions: string, materialGrade: string) => {
    const analysis = performTechnicalAnalysis({
      heatNumber: 'MANUAL',
      elements,
      hbValue: null,
      dimensions,
      materialGrade,
      aiInsights: 'Entrada manual de dados.'
    });
    setResults([analysis]);
    setSelectedHeatIndex(0);
    setShowManualInput(false);
    setError(null);
  };

  const generatePDF = async () => {
    if (!reportRef.current) return;
    const canvas = await html2canvas(reportRef.current, { scale: 2 });
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`Relatorio_Aco_${new Date().getTime()}.pdf`);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans pb-20">
      {/* Header */}
      <header className="bg-[#000066] text-white py-8 px-6 shadow-lg border-b border-blue-900">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-4">
            <div className="flex flex-col items-center justify-center border-2 border-white p-1 rounded-sm">
              <span className="text-2xl font-bold leading-none tracking-tighter">ds</span>
            </div>
            <div>
              <h1 className="text-3xl font-black tracking-tighter uppercase">DataSteel</h1>
              <p className="text-blue-300 text-xs font-bold uppercase tracking-[0.2em] opacity-80">Analisador de Equivalência A36</p>
            </div>
          </div>
          <div className="flex gap-4">
            <button 
              onClick={() => {
                setResults([]);
                setShowManualInput(false);
                setError(null);
              }}
              className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors text-sm font-semibold"
            >
              <RefreshCw className="w-4 h-4" />
              Nova Análise
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 mt-8">
        {/* Upload Section */}
        {results.length === 0 && !showManualInput && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden"
          >
            <div className="p-12 flex flex-col items-center text-center">
              <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mb-6">
                <Upload className="w-10 h-10 text-blue-600" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Upload do Certificado</h2>
              <p className="text-slate-500 max-w-md mb-8">
                Arraste seu certificado em PDF ou Imagem (JPG/PNG) ou clique para selecionar. Nossa IA irá extrair automaticamente os dados químicos e dimensionais.
              </p>
              
              <label className="relative group cursor-pointer">
                <input 
                  type="file" 
                  accept=".pdf,image/*" 
                  onChange={handleFileUpload}
                  className="hidden"
                  disabled={isAnalyzing}
                />
                <div className={cn(
                  "px-8 py-4 rounded-xl font-bold text-lg transition-all flex items-center gap-3",
                  isAnalyzing 
                    ? "bg-slate-100 text-slate-400 cursor-not-allowed" 
                    : "bg-blue-600 text-white hover:bg-blue-700 shadow-lg shadow-blue-200 hover:scale-105 active:scale-95"
                )}>
                  {isAnalyzing ? (
                    <>
                      <RefreshCw className="w-6 h-6 animate-spin" />
                      Analisando Certificado...
                    </>
                  ) : (
                    <>
                      <FileText className="w-6 h-6" />
                      Selecionar PDF
                    </>
                  )}
                </div>
              </label>

              <button 
                onClick={() => setShowManualInput(true)}
                className="mt-6 text-blue-600 font-semibold hover:underline flex items-center gap-1"
              >
                <Edit3 className="w-4 h-4" />
                Ou insira os dados manualmente
              </button>
            </div>
          </motion.div>
        )}

        {/* Manual Input Form */}
        {showManualInput && results.length === 0 && (
          <ManualInputForm onSubmit={handleManualSubmit} onCancel={() => setShowManualInput(false)} />
        )}

        {/* Heterogeneous Batch Warning */}
        {results.length > 1 && results.some(r => r.hbValue !== null) && results.some(r => r.hbValue === null) && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 p-6 bg-amber-50 border-l-4 border-amber-500 rounded-r-2xl shadow-md flex items-start gap-4"
          >
            <AlertCircle className="w-8 h-8 text-amber-600 flex-shrink-0" />
            <div>
              <h3 className="text-lg font-bold text-amber-900">⚠️ ATENÇÃO: Lote heterogêneo detectado</h3>
              <p className="text-amber-800">
                O certificado contém corridas com propriedades distintas. Algumas peças possuem dureza Brinell (HB) e são destinadas ao desgaste, enquanto outras são materiais estruturais. 
                <strong> As peças possuem aplicações e riscos de dobra distintos.</strong>
              </p>
            </div>
          </motion.div>
        )}

        {/* Results Section */}
        {results.length > 0 && (
          <div ref={reportRef} className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
            
            {/* Heat Selection Tabs */}
            {results.length > 1 && (
              <div className="flex flex-wrap gap-2 mb-6 no-print">
                {results.map((res, idx) => (
                  <button
                    key={res.heatNumber + idx}
                    onClick={() => setSelectedHeatIndex(idx)}
                    className={cn(
                      "px-4 py-2 rounded-lg font-bold text-sm transition-all border-2",
                      selectedHeatIndex === idx 
                        ? "bg-slate-900 border-slate-900 text-white shadow-md" 
                        : "bg-white border-slate-200 text-slate-600 hover:border-slate-300"
                    )}
                  >
                    Corrida: {res.heatNumber}
                  </button>
                ))}
              </div>
            )}

            {results[selectedHeatIndex] && (
              <div className="space-y-8 animate-in fade-in duration-500">
                <div className="flex items-center gap-4 mb-4">
                  <div className="bg-slate-900 text-white px-4 py-2 rounded-lg font-bold">
                    Análise Técnica - Corrida {results[selectedHeatIndex].heatNumber}
                  </div>
                </div>

                {/* Summary Cards */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Gauge Chart Card */}
                  <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-200 flex flex-col items-center justify-center">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Índice de Compatibilidade A36</h3>
                    <div className="h-64 w-full relative">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={[
                              { value: results[selectedHeatIndex].compatibilityIndex },
                              { value: 100 - results[selectedHeatIndex].compatibilityIndex }
                            ]}
                            cx="50%"
                            cy="50%"
                            innerRadius={80}
                            outerRadius={100}
                            startAngle={180}
                            endAngle={0}
                            paddingAngle={0}
                            dataKey="value"
                          >
                            <Cell fill={results[selectedHeatIndex].compatibilityIndex > 80 ? '#10b981' : results[selectedHeatIndex].compatibilityIndex > 60 ? '#f59e0b' : '#ef4444'} />
                            <Cell fill="#f1f5f9" />
                            <Label 
                              value={`${results[selectedHeatIndex].compatibilityIndex}%`} 
                              position="center" 
                              className="text-4xl font-bold fill-slate-900"
                            />
                          </Pie>
                        </PieChart>
                      </ResponsiveContainer>
                      <div className="absolute bottom-12 left-0 right-0 text-center">
                        <span className={cn(
                          "px-3 py-1 rounded-full text-xs font-bold uppercase",
                          results[selectedHeatIndex].compatibilityIndex > 80 ? "bg-emerald-100 text-emerald-700" : 
                          results[selectedHeatIndex].compatibilityIndex > 60 ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"
                        )}>
                          {results[selectedHeatIndex].compatibilityIndex > 80 ? "Alta Compatibilidade" : 
                           results[selectedHeatIndex].compatibilityIndex > 60 ? "Compatibilidade Moderada" : "Baixa Compatibilidade"}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Material Info Card */}
                  <div className="bg-white p-6 rounded-2xl shadow-md border border-slate-200 lg:col-span-2">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-6">Resumo do Material</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-4">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600">
                            <Settings className="w-6 h-6" />
                          </div>
                          <div>
                            <p className="text-xs text-slate-400 font-bold uppercase">Grau do Material</p>
                            <p className="text-lg font-bold text-slate-900">{results[selectedHeatIndex].materialGrade || "Não identificado"}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600">
                            <Beaker className="w-6 h-6" />
                          </div>
                          <div>
                            <p className="text-xs text-slate-400 font-bold uppercase">Carbono Equivalente (CE)</p>
                            <p className="text-lg font-bold text-slate-900">{results[selectedHeatIndex].ce.toFixed(3)}%</p>
                          </div>
                        </div>
                        {results[selectedHeatIndex].hbValue !== null && (
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center text-amber-600">
                              <ShieldCheck className="w-6 h-6" />
                            </div>
                            <div>
                              <p className="text-xs text-amber-500 font-bold uppercase">Dureza Brinell (HB)</p>
                              <p className="text-lg font-bold text-amber-900">{results[selectedHeatIndex].hbValue} HB</p>
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="space-y-4">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600">
                            <FileText className="w-6 h-6" />
                          </div>
                          <div>
                            <p className="text-xs text-slate-400 font-bold uppercase">Dimensões</p>
                            <p className="text-lg font-bold text-slate-900">{results[selectedHeatIndex].dimensions || "Não identificado"}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600">
                            <CheckCircle2 className="w-6 h-6 text-emerald-500" />
                          </div>
                          <div>
                            <p className="text-xs text-slate-400 font-bold uppercase">Status de Análise</p>
                            <p className="text-lg font-bold text-slate-900">Concluída</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Justification for HB */}
                {results[selectedHeatIndex].justification && (
                  <div className="bg-amber-50 border-l-4 border-amber-500 p-6 rounded-r-xl">
                    <p className="text-amber-900 font-medium">{results[selectedHeatIndex].justification}</p>
                  </div>
                )}

                {/* AI Insights */}
                {results[selectedHeatIndex].aiInsights && (
                  <div className="bg-blue-900 text-white p-8 rounded-2xl shadow-lg border border-blue-800">
                    <div className="flex items-center gap-3 mb-4">
                      <ShieldCheck className="w-6 h-6 text-blue-400" />
                      <h3 className="text-lg font-bold uppercase tracking-wider">Parecer Técnico da IA</h3>
                    </div>
                    <p className="text-blue-100 leading-relaxed text-lg italic">
                      "{results[selectedHeatIndex].aiInsights}"
                    </p>
                  </div>
                )}

                {/* Chemical Grid */}
                <div className="bg-white p-8 rounded-2xl shadow-md border border-slate-200">
                  <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-8">Análise Química Detalhada</h3>
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    {Object.entries(results[selectedHeatIndex].elements).map(([el, val]) => {
                      const v = val as number | null;
                      return <ElementCard key={el} label={el} value={v} status={getElementStatus(el as any, v)} />;
                    })}
                    <ElementCard label="CE" value={results[selectedHeatIndex].ce} status={getElementStatus('CE', results[selectedHeatIndex].ce)} isHighlight />
                  </div>
                </div>

                {/* Applicability Insights */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 shadow-sm">
                    <h4 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-3">Resistência ao Desgaste</h4>
                    <p className="font-bold text-slate-800 leading-relaxed">{results[selectedHeatIndex].applicability?.wearResistance}</p>
                  </div>
                  <div className={cn(
                    "p-6 rounded-2xl border-l-4 shadow-md",
                    results[selectedHeatIndex].applicability?.bendingAlert?.includes('✅') ? "bg-emerald-50 border-emerald-500" : "bg-red-50 border-red-500"
                  )}>
                    <h4 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-3">Processamento (Dobra)</h4>
                    <p className="font-bold text-slate-800 leading-relaxed">{results[selectedHeatIndex].applicability?.bendingAlert || "Não consta alerta específico."}</p>
                  </div>
                  <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 shadow-sm">
                    <h4 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-3">Usinagem / Solda</h4>
                    <p className="font-bold text-slate-800 leading-relaxed">{results[selectedHeatIndex].applicability?.machining}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex justify-center gap-4 pt-8 no-print">
              <button 
                onClick={generatePDF}
                className="flex items-center gap-2 px-8 py-4 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all shadow-lg"
              >
                <Download className="w-5 h-5" />
                Gerar Relatório PDF
              </button>
            </div>
          </div>
        )}

        {error && (
          <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-center gap-3 text-red-700 font-medium">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            {error}
          </div>
        )}
      </main>
    </div>
  );
}

const ElementCard: React.FC<{ label: string, value: number | null, status: Status, isHighlight?: boolean }> = ({ label, value, status, isHighlight }) => {
  const colors = {
    SAFE: "border-emerald-200 bg-emerald-50 text-emerald-700",
    WARNING: "border-amber-200 bg-amber-50 text-amber-700",
    CRITICAL: "border-red-200 bg-red-50 text-red-700"
  };

  return (
    <div className={cn(
      "p-4 rounded-xl border-2 flex flex-col items-center transition-all hover:scale-105",
      colors[status],
      isHighlight && "ring-2 ring-slate-900 ring-offset-2"
    )}>
      <span className="text-xs font-bold uppercase opacity-70 mb-1">{label}</span>
      <span className="text-xl font-bold">{value !== null ? value.toFixed(3) : 'N/C'}%</span>
    </div>
  );
}

function ManualInputForm({ onSubmit, onCancel }: { onSubmit: (elements: ChemicalElements, dimensions: string, materialGrade: string) => void, onCancel: () => void }) {
  const [elements, setElements] = useState<ChemicalElements>(INITIAL_ELEMENTS);
  const [dimensions, setDimensions] = useState('');
  const [materialGrade, setMaterialGrade] = useState('');

  const handleChange = (el: keyof ChemicalElements, val: string) => {
    setElements(prev => ({ ...prev, [el]: parseFloat(val) || 0 }));
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-white p-8 rounded-2xl shadow-xl border border-slate-200"
    >
      <div className="flex items-center gap-3 mb-8">
        <Edit3 className="w-6 h-6 text-blue-600" />
        <h2 className="text-2xl font-bold">Entrada Manual de Dados</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Grau do Material</label>
            <input 
              type="text" 
              value={materialGrade}
              onChange={e => setMaterialGrade(e.target.value)}
              placeholder="Ex: ASTM A36, SAE 1020"
              className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Dimensões</label>
            <input 
              type="text" 
              value={dimensions}
              onChange={e => setDimensions(e.target.value)}
              placeholder="Ex: 12.5mm x 2440mm x 6000mm"
              className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
        </div>
      </div>

      <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Composição Química (%)</h3>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
        {Object.keys(INITIAL_ELEMENTS).map((el) => (
          <div key={el}>
            <label className="block text-xs font-bold text-slate-500 mb-1">{el}</label>
            <input 
              type="number" 
              step="0.001"
              value={(elements as any)[el]}
              onChange={e => handleChange(el as keyof ChemicalElements, e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none font-mono"
            />
          </div>
        ))}
      </div>

      <div className="flex justify-end gap-4">
        <button 
          onClick={onCancel}
          className="px-6 py-2 text-slate-500 font-bold hover:bg-slate-50 rounded-lg transition-colors"
        >
          Cancelar
        </button>
        <button 
          onClick={() => onSubmit(elements, dimensions, materialGrade)}
          className="px-8 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
        >
          Analisar Dados
        </button>
      </div>
    </motion.div>
  );
}
