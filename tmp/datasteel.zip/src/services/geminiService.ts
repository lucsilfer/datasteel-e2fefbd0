import { GoogleGenAI, Type } from "@google/genai";
import { ChemicalElements } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const extractDataFromImage = async (base64Image: string): Promise<Array<{
  heatNumber: string;
  elements: ChemicalElements;
  hbValue: number | null;
  dimensions: string;
  materialGrade: string;
  aiInsights: string;
}> | null> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          parts: [
            {
              inlineData: {
                mimeType: "image/jpeg",
                data: base64Image.split(",")[1] || base64Image,
              },
            },
            {
              text: `Analise este certificado de aço e realize uma varredura cíclica para identificar todas as corridas (Heats) presentes.
              
              Para CADA corrida encontrada (identificada por termos como "Corrida", "Heat" ou "Heat No"), extraia:
              1. O número da corrida.
              2. A composição química (C, Si, Mn, P, S, Cr, Mo, Ni, Cu, V). Se um elemento não estiver presente, retorne null.
              3. O valor de Dureza Brinell (HB). MONITORE RIGOROSAMENTE o campo de propriedades mecânicas e observações em busca da unidade 'HB' ou 'Brinell'. Se detectar qualquer menção a HB (ex: HB 280, 400), extraia o valor numérico. Se não houver, retorne null.
              4. Dimensões e o grau do material vinculados àquela corrida.
              5. Um parecer técnico (aiInsights) em português focado na qualidade do material para aquela corrida específica.
              
              REGRAS IMPORTANTES:
              - Fidelidade aos Dados: Se um elemento químico ou o valor de HB não estiver presente, retorne null. Não especule valores.
              - Isolamento: A composição química e a dureza (HB) devem estar estritamente vinculadas ao seu respectivo número de corrida.
              - Detecção de HB: A presença de HB é um gatilho crítico para segurança operacional. Priorize a varredura deste campo.
              - Retorne uma lista de objetos JSON.`,
            },
          ],
        },
      ],
      config: {
        temperature: 0.1,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              heatNumber: { type: Type.STRING },
              elements: {
                type: Type.OBJECT,
                properties: {
                  C: { type: Type.NUMBER, nullable: true },
                  Si: { type: Type.NUMBER, nullable: true },
                  Mn: { type: Type.NUMBER, nullable: true },
                  P: { type: Type.NUMBER, nullable: true },
                  S: { type: Type.NUMBER, nullable: true },
                  Cr: { type: Type.NUMBER, nullable: true },
                  Mo: { type: Type.NUMBER, nullable: true },
                  Ni: { type: Type.NUMBER, nullable: true },
                  Cu: { type: Type.NUMBER, nullable: true },
                  V: { type: Type.NUMBER, nullable: true },
                },
                required: ["C", "Si", "Mn", "P", "S", "Cr", "Mo", "Ni", "Cu", "V"],
              },
              hbValue: { type: Type.NUMBER, nullable: true },
              dimensions: { type: Type.STRING },
              materialGrade: { type: Type.STRING },
              aiInsights: { type: Type.STRING },
            },
            required: ["heatNumber", "elements", "dimensions", "materialGrade", "aiInsights"],
          },
        },
      },
    });

    const result = JSON.parse(response.text || "[]");
    return result;
  } catch (error) {
    console.error("Error extracting data:", error);
    return null;
  }
};
